<?php
include 'database.php';
			 		//$id = isset($_POST['id']) ? $_POST['id'] : '';
					$captain_name= isset($_POST['name']) ? $_POST['name'] : '';				
					$collage= isset($_POST['collage']) ? $_POST['collage'] : '';
					$phone_number= isset($_POST['phonenumber']) ? $_POST['phonenumber'] : '';
					$branch= isset($_POST['branch']) ? $_POST['branch'] : '';
					$email= isset($_POST['email']) ? $_POST['email'] : '';
					$participant1= isset($_POST['name1']) ? $_POST['name1'] : '';
					$participant2= isset($_POST['name2']) ? $_POST['name2'] : '';

$sql =mysqli_query($con, "insert into event1(captain_name, collage, phone_number, branch, email, part1, part2) values('$captain_name','$collage', '$phone_number','$branch', '$email', '$participant1', '$participant2')")or die(mysqli_error($con)); 
	
	if ($con->query($sql) === TRUE) {
		 echo '<script>alert("Successfully Submited!!!")</script>';
		 echo "<script>windows:location='form.php'</script>";
	}

?>